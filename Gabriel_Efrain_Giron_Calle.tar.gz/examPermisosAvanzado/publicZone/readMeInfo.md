El archivo readme nos sirve para llevar un registro de lo avanzado en nuestro repositorio
Markdown es un lenguaje de marcado que permite dar formato a documentos de texto sin formato.
