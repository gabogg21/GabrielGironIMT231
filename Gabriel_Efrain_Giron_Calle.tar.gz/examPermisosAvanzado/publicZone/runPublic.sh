#!/bin/bash
echo "Hola, mi carrera es
$CarreraDeEstudiante."
