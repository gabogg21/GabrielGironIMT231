#!/bin/bash
echo "Mostrando los archivos de examFinalAvanzado..."
ls examPermisosAvanzado
