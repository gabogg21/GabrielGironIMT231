#!/bin/bash
echo "Limpiando /papelera"
