#!/bin/bash
echo "Bienvenido al script del examen"
echo "Porfavor ingrese su nombre:"
read nombre
echo "Hola, $nombre"
echo "El contenido de la carpeta tarea3 es:"
tree
echo "Ha finalizado el script"
